# README

Group 9

Ziqi Tan, U88387934, ziqi1756@bu.edu

Xueyan Xia, U82450191, xueyanx@bu.edu

## Collaboration
Pair programming and debugging.

## How to run this program?
Just run main.cpp.

## Result
```
Running ...
It takes 20 seconds or so ...
ordinary fashion takes 17.4432 seconds.
new method takes 3.63723 seconds.
validating results: true
```

The old fashion method takes much more time than the method which makes full use of cache locality.
