# Assignment 8 CUDA Programming 
Group 9

Ziqi Tan, U88387934, ziqi1756@bu.edu

Xueyan Xia, U82450191, xueyanx@bu.edu

## Collaboration
Pair discussing, designing, programming and debugging.

## Compile instructions
```
$ nvcc -o two_sum two_sum.cu
$ ./two_sum
```

## Result
```
Running sequential version: 
Time: 3.05472
Running cuda version: 
Time: 1.99212
True
speedup: 1.5334
efficiency: 1.42809e-09
```


